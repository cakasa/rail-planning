
/* 2012 (C) Jussi Rintanen  */

void cleanupoperators();
