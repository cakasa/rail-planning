
/*   2010 (C) Jussi Rintanen   */

/* Literal and types:

 */

#define UNASS -1

int propagate(satinstance);

void init_clausesets();
